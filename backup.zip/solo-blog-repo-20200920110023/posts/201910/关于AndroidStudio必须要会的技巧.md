title: 关于 Android Studio 必须要会的技巧
date: '2019-10-14 17:53:11'
updated: '2019-10-14 17:53:11'
tags: [Android, Coder]
permalink: /articles/2019/10/14/1571046791204.html
---
![](https://img.hacpai.com/bing/20180804.jpg?imageView2/1/w/960/h/520/interlace/1/q/100)

# 序言
开始Codeing的第一步就是熟悉你的Ide,熟练使用你的开发工具能极大的提高你的开发效率和撸代码的体验，下面总结几个必须要会的关于Android Studio 的小技巧或快捷键。

## 1.layout preview
很多Android初学者编码的时候写UI往往是写了一段就开始run到实机看效果，有时候为了改个padding或者textcolor就需要重新编译，耗费非常多的不必要的时间。其实Android Studio已经为你考虑到了。编写UI的时候只需要点击右上导航栏Gradle上方的Preview就可以看到UI效果了，你可以一边撸码，一边看到显示效果。
![201901221.png](https://img.hacpai.com/file/2019/04/201901221-1508b24c.png)


## 2.代码跟踪/打开实现
代码跟踪是个特别实用的东西，你只需要在类或参数的位置按住Ctrl + 鼠标左键就能看到类或参数的使用位置，这个东西初学者都知道。还有一个类似的东西是打开实现。用于快速的看到interface类被实现的地方，在MVP框架中，这个小技巧能很快的帮助你找到interface的实现，操作方法就是Ctrl + alt + 鼠标左键。

## 3.返回上/下个光标位置
在编写代码的时候经常会跳转到不同的类，如果你想回到刚刚上一个类跳转的位置，这个快捷键可以帮到你 Ctrl + alt + 左/右 方向键。

## 4.书签
你可以在某处做个标记（书签），方便后面再跳转到此处。对于需要频繁定位的位置，你可以使用该技巧给该位置加个书签。
按Ctrl + F11后选择tag,以后使用Ctrl + tag可以快速跳转到该位置，按Shift + F11可以看到所有mark.按Ctrl + F11取消mark.
![201901222.jpg](https://img.hacpai.com/file/2019/04/201901222-2fd5fbe3.jpg)


## 5.快速查看定义
该操作能让你快速的看到一个方法或者类的具体实现。Ctrl + Shift + I
![201901223.jpg](https://img.hacpai.com/file/2019/04/201901223-425507ed.jpg)

## 6.文件结构弹窗
显示类里所有的方法或参数，快速定位到要跳转的位置Ctrl + F12
![201901224.jpg](https://img.hacpai.com/file/2019/04/201901224-8698be1a.jpg)