title: 记录Solo Blog Google Adsense广告接入问题
date: '2019-12-18 14:08:54'
updated: '2019-12-18 14:08:54'
tags: [Coder]
permalink: /articles/2019/12/18/1576649334695.html
---
![](https://img.hacpai.com/bing/20181225.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

之前看到这位大佬 https://hacpai.com/article/1575989967191 的博客也想尝试一下申请Google 广告。

首先开始申请Adsense 它会提示你粘贴这个代码在blog的head里面
![image.png](https://img.hacpai.com/file/2019/12/image-74bbcc00.png)

但是我将代码复制到HTML Head里面它还是提示我未找到该代码
经过排查发现 我没有将我的博客域名 moyck.com 反向代理到 www.moyck.com 导致它找不到网页（请确保不带www的能正常访问）

解决这个问题后就可以提交审核了

本来以为审核能顺利进行，审核了三次都是提示  
#### 内容抄袭
我的博客是百分百原创的，但是有转载到知乎 CSDN里面，可能这就导致Goolge认为我抄袭了
于是把外站的转载都关闭重新提交。

没想到还是审核不通过 提示我内容抄袭....

实在没办法，就在博客里面发了一个新的文章（审核过了就删除了）

文章名为：  关于Google Adsense申请审核

内容就是说本站的文章百分百原创，但是有转载到别的外站，并且附带英文翻译

本来也不抱希望了，没想到这次居然真的通过了~ 看来审核人员还是会仔细看的

然后就可以进行广告设置
这里有两种广告方式
#### 自动广告 （由Google帮你分析页面哪里适合放置广告，打开就可以了）
#### 广告单元 （手动创建单元，手动添加代码）
![Screenshot20191218134913Chrome1.jpg](https://img.hacpai.com/file/2019/12/Screenshot20191218134913Chrome1-0feefe81.jpg)

![Screenshot20191218135023Chrome1.jpg](https://img.hacpai.com/file/2019/12/Screenshot20191218135023Chrome1-fb119f58.jpg)


由于自动广告的放置位置我觉得对用户体验有点影响，于是使用了单元广告

![Screenshot20191218140434Chrome.jpg](https://img.hacpai.com/file/2019/12/Screenshot20191218140434Chrome-e56ebe7e.jpg)

考虑到用户体验，我将广告放到了签名档里面

![image.png](https://img.hacpai.com/file/2019/12/image-588eeb81.png)

可以在这里看到效果，当然顺手帮我点下广告那就更感谢了~


[进入我的博客看看效果](http://www.moyck.com:8080/articles/2019/11/29/1575013596580.html)


~~~

~~~