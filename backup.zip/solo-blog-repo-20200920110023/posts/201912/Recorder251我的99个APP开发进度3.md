title: Recorder251 - 我的 99 个 APP 开发进度 (3)
date: '2019-12-11 17:11:33'
updated: '2019-12-11 17:11:33'
tags: [Android, Coder]
permalink: /articles/2019/12/11/1576055493187.html
---
![微信图片20191211170929.jpg](https://img.hacpai.com/file/2019/12/微信图片20191211170929-76ed1b09.jpg)

# 序言
之前心血来潮开始了开发99个APP的计划，这是我的第三个APP Recorder251~（撒花）
看到这个APP的名字，懂的人大概会心一笑了。这个APP的创作灵感就是华为李宏远事件。华为前员工李洪元被华为举报涉嫌敲诈导致被刑拘251天。首先，我算是华为的花粉，鸿蒙发布会时我就在现场的最前排。但当我看到李洪元事件的发生的全知乎的删帖，热度的减退，心里有了点别扭。这就是开发这个APP的背景了。


# 简介
这个APP看上去跟Chrome非常相似，但是实际上它是一个录音机。除了正常的网页浏览外，当点击菜单列的星星按钮后就会开始录音，重新点击星星就会保存录音。
![Screenshot20191211103949Recoder251.jpg](https://img.hacpai.com/file/2019/12/Screenshot20191211103949Recoder251-cabaf9f6.jpg)![Screenshot20191211103955Recoder251.jpg](https://img.hacpai.com/file/2019/12/Screenshot20191211103955Recoder251-9aae2116.jpg)


点击星星旁边的下载按钮就可以跳转到录音记录界面

![Screenshot20191211104001Recoder251.jpg](https://img.hacpai.com/file/2019/12/Screenshot20191211104001Recoder251-19335448.jpg)

当然其他菜单按钮是没有作用的（doge)

![Screenshot20191211104006Recoder251.jpg](https://img.hacpai.com/file/2019/12/Screenshot20191211104006Recoder251-a2160525.jpg)

夹带了私货，点击home按钮后，会进入到我的Blog

![Screenshot20191211135730Recoder251.jpg](https://img.hacpai.com/file/2019/12/Screenshot20191211135730Recoder251-1afcbf37.jpg)


# 尾语
这个App功能较为简单，技术知识就不写啦。另外，欢迎来知乎给我一个Start,或许能让你发现一个有趣的人~

[我的知乎](https://www.zhihu.com/people/du-li-te-xing-de-qin-zi/answers)

<a href="http://www.moyck.com:8080/articles/2019/12/11/1576055493187.html">我的99APP开发进度</a><br>