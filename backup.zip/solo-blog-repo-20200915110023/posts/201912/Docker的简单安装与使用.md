title: Docker的简单安装与使用
date: '2019-12-21 11:13:39'
updated: '2019-12-21 11:13:39'
tags: [Coder]
permalink: /articles/2019/12/21/1576898019847.html
---
![null](https://imgconvert.csdnimg.cn/aHR0cDovL3VwbG9hZC1pbWFnZXMuamlhbnNodS5pby91cGxvYWRfaW1hZ2VzLzE3NTQ3NzI4LTFhOTY5MTAxOWQxOWRlMzg?x-oss-process=image/format,png)
# 序言
因为在工作中有给APP优化电量消耗的需求，因此了解到了[battery-historian](https://github.com/google/battery-historian)这个google出品的电量分析工具。它的配置方式有两种其一是下载go，python,git,对源码进行编译，但是该方法过程有点繁琐。第二种方式就是下载Docker一键配置环境，我这里用的就是方法二。

## 1.什么是Docker
不知道你有没有经历过配置ADT（Android Developer Tools）的经历,在大学期间配置这个环境对于新手的我来说那是噩梦般的体验。首先需要安装JDK，配置JAVA环境，下载安装eclipse，在eclipse上安装ADT插件，下载SDK，配置NDK工具路径和环境等等..经过N多的步骤后，当你以为到达黎明前夕时点击运行分分钟报出各种匪夷所思的问题，又得焦头烂额的搜索各种解决方案。如果你觉得这些还好，那对于linux环境几十个依赖的环境配置不知道你会作何感想。为了解决环境依赖的问题Docker横空出世，它实际上就是一个虚拟机，能通过一个命令将完整的一个环境下载下来，你不再需要为了各种兼容或者依赖等问题而挠头。（为了保护程序员的头发作出了史诗级的贡献）

## 2.怎么安装Docker
我的工作环境是win10，因此可以直接用[Docker for windows](https://www.docker.com/products/docker-desktop)安装 （需要开启Hyper-V）
至于win7,8 或类unix系统本人并没有实际安装过，可以自行参考下方参考资料
当你在终端命令行输入docker有帮助显示就证明安装成功了

![在这里插入图片描述](https://imgconvert.csdnimg.cn/aHR0cDovL3VwbG9hZC1pbWFnZXMuamlhbnNodS5pby91cGxvYWRfaW1hZ2VzLzE3NTQ3NzI4LWI1MmEzMDI5ZDM5ZTRlNGE?x-oss-process=image/format,png)

## 3.怎么使用
Docker安装好后接下来需要运行我们的工具。在我上面提到的battery-historian首页就有这么一个命令
```
docker -- run -p <port>:9999 gcr.io/android-battery-historian/stable:3.0 --port 9999
```
大部分的Docker应用都是通过调用类似的这种命令来执行需要的程序 其中的port需要填入你随便一个空闲的端口，比如我这里填的是9999那我就可以通过localhost:9999来访问这个应用，而gcr.io/android-battery-historian/stable:3.0就是我们应用的地址
讲道理的话，输入命令Docker会自动帮助我们下载并运行这个应用。



...然而它似乎不打算跟我讲道理
![在这里插入图片描述](https://imgconvert.csdnimg.cn/aHR0cDovL3VwbG9hZC1pbWFnZXMuamlhbnNodS5pby91cGxvYWRfaW1hZ2VzLzE3NTQ3NzI4LWMwZTI5YjhlNjBjODQxODQucG5n?x-oss-process=image/format,png)
没关系，社会主义接班人从不认输，出现这个问题的原因是因为国情原因，gcr.io这个网址我们上不去，可以通过翻墙来解决，如果没有VPN的话一般遇到这种情况都应该去搜索一下有没有国内能用的镜像，于是感谢马云爸爸[阿里云镜像](https://dev.aliyun.com/list.html?namePrefix=battery-historian)找到你需要的应用，可以看到阿里云提供的镜像地址

然而，写代码很少说能顺风顺水的，它那个复制地址的JS按钮，我把鼠标按坏了也没能把那个地址复制下来，而且它的完整地址还做了省略....

![在这里插入图片描述](https://imgconvert.csdnimg.cn/aHR0cDovL3VwbG9hZC1pbWFnZXMuamlhbnNodS5pby91cGxvYWRfaW1hZ2VzLzE3NTQ3NzI4LThlYjFjM2M3NjlmZGJiMjYucG5n?x-oss-process=image/format,png)

唔紧要，少少苦楚等于激励，通过黑科技F12找到这个地址的span 将它的CSS去掉，当当当当~
![在这里插入图片描述](https://imgconvert.csdnimg.cn/aHR0cDovL3VwbG9hZC1pbWFnZXMuamlhbnNodS5pby91cGxvYWRfaW1hZ2VzLzE3NTQ3NzI4LTVjZGVkZDI0NWFlYTM2ZmYucG5n?x-oss-process=image/format,png)

![在这里插入图片描述](https://imgconvert.csdnimg.cn/aHR0cDovL3VwbG9hZC1pbWFnZXMuamlhbnNodS5pby91cGxvYWRfaW1hZ2VzLzE3NTQ3NzI4LTYwODM1ZTExODA3MjU3N2MucG5n?x-oss-process=image/format,png)
接下来把该地址直接在终端中运行，现在可以顺利的下载了，接下来通过docker run命令终于顺利的部署好我们要的应用了。



打开localhost:9999
享用！

![在这里插入图片描述](https://imgconvert.csdnimg.cn/aHR0cDovL3VwbG9hZC1pbWFnZXMuamlhbnNodS5pby91cGxvYWRfaW1hZ2VzLzE3NTQ3NzI4LTJmNjNjMTgwZjMxMTgwNTU?x-oss-process=image/format,png)

# 4.尾语
这篇文章其实纯属是记录自己学习Docker踩到的坑，当然能给别人带来帮助那就更好了。


# 参考资料
Docker的安装和使用（类unix）https://blog.csdn.net/winycg/article/details/80544624
Docker的安装和使用（windows）https://blog.csdn.net/winycg/article/details/80544624
Hello World校验Docker的安装 https://blog.csdn.net/chszs/article/details/48224977

---
这里有更多有深度的开发经验 My Blog: www.moyck.com

~~~
~~~