title: Andorid 耗电优化与 battery-historian 的基本使用
date: '2019-10-14 17:51:52'
updated: '2019-10-14 17:51:52'
tags: [Android, Coder]
permalink: /articles/2019/10/14/1571046711964.html
---
![](https://img.hacpai.com/bing/20180606.jpg?imageView2/1/w/960/h/520/interlace/1/q/100)

MyBlog www.moyck.com

# 序言 
上篇文章 [Docker的简单安装与使用](http://www.moyck.com/articles/2019/12/21/1576898019847.html)讲到了battery-historianh的安装和配置，这次记录的就是battery-historianh的使用和Android耗电优化的一些想法。

## 1.简介
公司的一个项目就是通过蓝牙不断搜索附近的设备，当搜到设备或者设备消失时会将设备ID和当前定位坐标发送到服务器。然而客户反映该APP耗电过于严重。因此我的任务就是找到耗电严重的原因并且 fix it!通过搜索发现了一个好用的电量消耗分析的工具。[battery-historian](https://github.com/google/battery-historian)这个工具是Google的出品，能通过图表直观的看到设备各个模块或者进程消耗的电量。开始解决问题之前必须找到问题的核心和思路，毕竟知自知彼百战不殆。

## 2.battery-historian的安装配置
参考上篇文章[Docker的简单安装与使用](http://moyck.com:8080/articles/2019/04/15/1555324497009.html)。如果发现配置失败也没关系，这里有个别人搭好的环境可以直接用 [https://bathist.ef.lc/](https://bathist.ef.lc/)。在我配置了一天Docker之后才发现这个网址，令人窒息。所以说能用谷歌就别用百度。

## 3.准备工作
在终端输入如下代码开启Android电量监控（别告诉我你不知道adb）
```
adb shell dumpsys batterystats –enable full-wake-history
```
输入如下代码重置监控文件
```
adb shell dumpsys batterystats –reset
```
当你认为监控时间足够长，可以用如下代码在当前目录输出监控文件
```
adb bugreport > bugreport.txt
```

这个就是我们的输出文件

![10110.png](https://img.hacpai.com/file/2019/04/10110-e476528a.png)

## 4.怎么使用
进入battery-historian后会看到这样的界面
![10114.png](https://img.hacpai.com/file/2019/04/10114-f8011d19.png)

点击Browse选择我们的输出文件就可以进入到分析界面
点击Switch.... 可以同时输入多个文件并行比较分析

![10113.png](https://img.hacpai.com/file/2019/04/10113-5ff60f67.png)

进入分析界面就可以看到这么复杂的图表，然而我们实际上关注的内容不多，在Android app中主要的耗电大户就是

WakeLocks：***在Android的运行机制里，当手机空闲时会进入到休眠状态。而wakeloack的作用就是禁止系统进入休眠，硬件保持高能耗运行从而可以实现关屏唤醒等毒瘤操作。***
Screen： ***用于判断手机屏幕是否点亮，可以和其他信息结合用于分析关屏休眠下的手机运行状态。***
Top app： ***当前最顶端显示的APP***
GPS： ***如果你的app用到了GPS，应该关注这里的使用时间***
Wifi scan：***我的项目app需要频繁搜索附近的wifi，因此这里也是我主要关注的地方***

## 5.分析过程
实际上仅仅这样观察数据对我来说可能并不够直观，因此我首先重启手机，保持屏幕唤醒并且不做任何操作，记录一份正常系统运行的电量分析报告。
![10113.png](https://img.hacpai.com/file/2019/04/10113-f9db4fce.png)


可以看到右下角的电量消耗报告 在50分钟里掉了10%的电量，平均每小时掉电11.81%。在屏幕常亮的状态下有这种数据还是挺不错的。

接着，打开自己的app，重新记录一份数据
![10112.png](https://img.hacpai.com/file/2019/04/10112-395e3f05.png)


结果真的让我很惊讶了，在40分钟里，掉了19%的电量，平均每小时掉电29.5%。粗略的说也就是我的app让手机每小时多掉了接近20%的电量。

这个时候就可以结合两个图片来观察对比多消耗的电量用在什么地方，可以直观的发现，我的app的wifi scan频率达到多得过分的程度。审查代码发现这也是由于业务逻辑的关系。
如果问题跟业务有关就需要跟产品经理商量，确定解决方案，定制相应的解决方案才能开始下一步。

修改完成后再次测试
![10125.png](https://img.hacpai.com/file/2019/04/10125-eb099abc.png)

可以看到修改Wifi模块后电量消耗降低了6%左右。对于这种手机设备来说也是很大的进步了。

当然battery-historian的功能远不止那么少
![10121.png](https://img.hacpai.com/file/2019/04/10121-61133e89.png)

在该列表可以数值化的看到手机各个模块分别的运行情况
![10122.png](https://img.hacpai.com/file/2019/04/10122-cc9d10ab.png)

这个List就是显示各模块每个进程分别消耗了多少电量

关键的Device's Power Estimates能看到每个进程总体电量消耗
![10123.png](https://img.hacpai.com/file/2019/04/10123-8e8c7045.png)


在App Selection还可以选择你要观察的进程
![10120.png](https://img.hacpai.com/file/2019/04/10120-719d813d.png)


## 6.关于代码
上面说的都是关于数据分析的内容，没有提到具体的优化方法。要是你有优化电量的需求可以按照如下思路
  1.熟悉代码，了解自己的项目是最基础的，哪里用到wakelocak，哪里有循环获取gps，哪里有不断scan附近的wifi要做到心里有数
  2.首先应该通过工具关注自己是否有长时间持有wakelocak，这是耗电的头号大户，分析逻辑决定能否降低持有时间
  3.某些时候不需要不断获取新的数据就可以使用缓存把数据保存下来然后降低刷新的频率（蓝牙，gps模块）
  4.具体问题具体分析
  
# 尾语
电量消耗优化的相关资料暂时还是比较少，国内相对来说很少有开发者会关注电量消耗，但实际上每个合格的开发者都应该尽量的优化好自己的app,一个好的生态需要共同努力。


# 参考资料
官方文档 https://developer.android.com/topic/performance/power/battery-historian
Android电量优化CSDN https://blog.csdn.net/itheimach/article/details/70545139