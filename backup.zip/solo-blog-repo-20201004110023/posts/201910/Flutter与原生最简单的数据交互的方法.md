title: Flutter 与原生最简单的数据交互的方法
date: '2019-10-14 17:55:49'
updated: '2019-10-14 17:55:49'
tags: [Coder, Flutter]
permalink: /articles/2019/10/14/1571046949161.html
---
![](https://img.hacpai.com/bing/20190225.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# 序言 
这次开发的App跟BLE Beacon相关，原生负责搜索附近的Beacon数据并上报到服务器，Flutter端作为信息展示。本来两边是泾渭分明的，但是原生这边需要获取到Flutter端请求的Token作为服务器身份验证。于是有了这篇最简单的数据交互方法。

## 1.SharedPreferences
本来打算按部就班的按照 [Flutter与原生(Android)的交互](https://www.jianshu.com/p/c5263a3d7aac)  实现交互方法的。跟前端小伙伴简单沟通了下，发现Flutter端是使用名为SharedPreferences的插件保存Token的。作为Android 开发者，对这个名字应该相当熟悉了。如果它的机制跟Android 原生的SharedPreferences一样保存为本地Xml,那我岂不是连交互方法都不用写就能获取到他的Token了。

## 2.分析源码
这里是SharedPreferences的[源码地址](https://github.com/jsoref/flutter-plugins/tree/master/packages/shared_preferences)

![image.png](https://img.hacpai.com/file/2019/04/image-030b7e43.png)
从目录可以看到其实这个Flutter插件本质也只是一个Flutter项目，android 与 ios 文件夹分别对应不同的实现。我们进到android目录下看看到底是怎么实现的。

![image.png](https://img.hacpai.com/file/2019/04/image-eb13be3f.png)
这个插件的实现还是比较简单的，SharedPreferencesPlugin就是核心类

![image.png](https://img.hacpai.com/file/2019/04/image-5bb2cdd6.png)

这个类实现了MethodCallHandler，通过android.content.SharedPreferences给Flutter端暴露相关get put 方法，可以看到SP的文件名即是FlutterSharedPreferences

向前端小伙伴要了key，在原生这边尝试读取这个token
```
sharedPreferences = getSharedPreferences(SHARED_PREFERENCES_NAME, Context.MODE_PRIVATE)
val token = sharedPreferences.getString("accesstoken", "null")
```
正当自信满满的以为能成功读取发现拿到的String居然为null，这不合理呀。
不过没关系，SharedPreferences是保存在data 里面 shared_prefs 文件夹内
打开手机目录data/data/com..../shared_prefs 看到确实存在FlutterSharedPreferences.xml文件

![image.png](https://img.hacpai.com/file/2019/04/image-d02bc5f2.png)

![image.png](https://img.hacpai.com/file/2019/04/image-2812f93e.png)

原来默认在前面加了一个flutter.前缀，只扫了两眼源码粗心忽略了...补上一个前缀就可以正常读取了

附上IOS端的实现，也比较简单只是使用了NSUserDefaults
![image.png](https://img.hacpai.com/file/2019/04/image-5e19a2fa.png)

## 3.尾语
这个方法虽然简单，局限性也很大。不过很适合我这种场景，我始终认为方法千千万，没必要一定按照常规做法，适合自己的才是好方法。