title: 关于Moyck
date: '2019-11-29 15:46:36'
updated: '2019-12-03 12:22:00'
tags: [Android, Coder, 杂谈]
permalink: /articles/2019/11/29/1575013596580.html
---

![](https://img.hacpai.com/bing/20190311.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# 关于
我是Moyck，一位个人开发者
### 感谢每个能看到这里的人
我是个沉没寡言的人，从小就喜欢玩各种电子设备
可能就是因为对电子设备这份喜欢，让我走上了编程的路并乐此不疲
在现实生活中，我是一间外包公司里唯一的Android开发工程师
常常同时要进行多个项目，每天都很忙碌但感觉日子并不充实

想了想，身不由己的工作似乎有点辜负了当年满怀梦想的自己

于是，我决心要做一位独立开发者，做自己所喜欢的事情

#### 从今起，我会不定时在 Blog/知乎/CSDN 里面发布我开发的 IOS / Android App 或 游戏 或 小说

一般，我会将我工作中学到的一个知识点作为一个App，并会附带该App的相关知识点，以供要实现该功能的开发者参考。

最后，我并不想在我的App里增加广告（除非成本过高无法负担），服务器域名等都需要我个人支付，如果你喜欢我的创作，可以请我喝杯咖啡~
  
### 已实现的APP

#### 条码大师 
平台：Android （不发布）
简介：识别或生成二维码，条形码
下载：[barcodemaster.zip](https://img.hacpai.com/file/2019/12/barcodemaster-8b09da8d.zip)

技术参考： [Android 二维码/条形码的识别或生成](http://www.moyck.com:8080/articles/2019/11/29/1575025314278.html)

![FotoJet.jpg](https://img.hacpai.com/file/2019/11/FotoJet-f56ffcea.jpg)

