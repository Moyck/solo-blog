title: Android常用的蓝牙，GPS，网络等状态检测方法汇总
date: '2019-10-14 18:21:07'
updated: '2019-10-14 18:21:07'
tags: [Android, Coder]
permalink: /articles/2019/10/14/1571048467278.html
---
![](https://imgconvert.csdnimg.cn/aHR0cHM6Ly9pbWcuaGFjcGFpLmNvbS9iaW5nLzIwMTgwMjE4LmpwZw?x-oss-process=image/format,png) 

# 序言
记录Android的一些判断网络，蓝牙，GPS，等设备状态的方法。

## 1.判断网络是否可用
~~~
// 是否有可用网络
	private boolean isNetworkConnected() {
		ConnectivityManager cm = 
				(ConnectivityManager) mContext.getSystemService(Context.CONNECTIVITY_SERVICE);
		NetworkInfo network = cm.getActiveNetworkInfo();
		if (network != null) {
			return network.isAvailable();
		}
		return false;
	}

~~~

## 2.判断wifi是否可用
~~~
// Wifi是否可用
	private boolean isWifiEnable() {
		WifiManager wifiManager = (WifiManager) mContext
				.getSystemService(Context.WIFI_SERVICE);
		return wifiManager.isWifiEnabled();
	}

~~~

## 3.判断GPS是否可用
~~~
// Gps是否可用
	private boolean isGpsEnable() {
		LocationManager locationManager = 
				((LocationManager) mContext.getSystemService(Context.LOCATION_SERVICE));
		return locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
	}

~~~

## 4.判断蓝牙是否可用
~~~
// 蓝牙是否可用
public static boolean isBluetoothEnabled() {
    BluetoothAdapter bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
 if (bluetoothAdapter != null) {
        return bluetoothAdapter.isEnabled();
  }
    return false;
}
~~~

## 5.判断是否有SIM卡
~~~
/**
 * 判断是否包含SIM卡
 *
 * @return 状态
 */
public static boolean ishasSimCard(Context context) {
    TelephonyManager telMgr = (TelephonyManager)
            context.getSystemService(Context.TELEPHONY_SERVICE);
    int simState = telMgr.getSimState();
    boolean result = true;
    switch (simState) {
        case TelephonyManager.SIM_STATE_ABSENT:
            result = false; // 没有SIM卡
            break;
        case TelephonyManager.SIM_STATE_UNKNOWN:
            result = false;
            break;
    }
    Log.d(TAG, result ? "有SIM卡" : "无SIM卡");
    return result;
}
~~~

## 6.判断是否存在SD卡
~~~
// 是否存在SD卡
private boolean ExistSDCard() {  

    if (android.os.Environment.getExternalStorageState().equals(  

    android.os.Environment.MEDIA_MOUNTED)) {  

    return true;  

    } else  

    return false;  

    }
~~~

## 7.判断屏幕是否点亮
~~~
//判断屏幕是否点亮
public static boolean isScreenOn(){
    PowerManager pm = (PowerManager) context.getSystemService(Context.POWER_SERVICE);
    boolean isScreenOn = pm.isScreenOn();
    return isScreenOn;
}
~~~

## 8.判断软键盘是否打开
~~~
//判断软键盘是否打开
 public boolean isSoftShowing() {
        //获取当前屏幕内容的高度
        int screenHeight = getWindow().getDecorView().getHeight();
        //获取View可见区域的bottom
        Rect rect = new Rect();
        getWindow().getDecorView().getWindowVisibleDisplayFrame(rect);
 
        return screenHeight - rect.bottom != 0;
    }

~~~

## 9.判断自动旋转屏幕是否打开
~~~
// 判断自动旋转屏幕是否打开
public boolean isAutoRotate(){
    int screenchange = Settings.System.getInt(context.getContentResolver(), Settings.System.ACCELEROMETER_ROTATION);
    if (screenchange == 1) {
        return true;
	 }else {
        return false;
	 }
}
~~~

## 10.判断是否在播放音频
~~~
// 判断是否在播放音频
public static boolean isMusicPlay(){
    AudioManager audioManager = (AudioManager)getContext().getSystemService(Context.AUDIO_SERVICE);
    return audioManager.isMusicActive();
}
~~~
___
My Blog: www.moyck.com
