title: 关于Moyck
date: '2019-11-29 15:46:36'
updated: '2019-12-06 21:34:47'
tags: [Android, Coder, 杂谈]
permalink: /articles/2019/11/29/1575013596580.html
---

![](https://img.hacpai.com/bing/20190311.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# 关于
我是Moyck，一位个人开发者
### 感谢每个能看到这里的人
我是个沉没寡言的人，从小就喜欢玩各种电子设备
可能就是因为对电子设备这份喜欢，让我走上了编程的路并乐此不疲
在现实生活中，我是一间外包公司里唯一的Android开发工程师
常常同时要进行多个项目，每天都很忙碌但感觉日子并不充实

想了想，身不由己的工作似乎有点辜负了当年满怀梦想的自己

于是，我决心要做一位独立开发者，做自己所喜欢的事情

#### 从今起，我会不定时在 Blog/知乎/CSDN 里面发布我开发的 IOS / Android App 或 游戏 或 小说

#### 计划发布99个APP为止

#### 另外因为上架应用商店都需要软件著作权，因此选择蒲公英分发，密码默认 0000

一般，我会将我工作中学到的一个知识点作为一个App，并会附带该App的相关知识点，以供要实现该功能的开发者参考。

另外，我的APP尽量没有广告（除非成本过高），如果你喜欢我的创作，可以请我喝杯奶茶～

### 已实现的APP

#### 条码大师 
平台：Android 
简介：识别或生成二维码，条形码
时间：2019/12/2
下载：https://www.pgyer.com/NcP1 密码 0000

技术参考： [Android 二维码/条形码的识别或生成](http://www.moyck.com:8080/articles/2019/11/29/1575025314278.html)

![FotoJet.jpg](https://img.hacpai.com/file/2019/11/FotoJet-f56ffcea.jpg)


#### 简创 （暂定）
平台：Android / IOS（待发布）
简介：既然开始决心做APP开发，自然需要UI设计了。总不能边写界面边调整吧。鉴于本人PS,XD都是半桶水水平，那干脆自己撸一个可以设计UI的APP吧！ 该APP是用Flutter写的，因此兼容Android IOS，并且得益于Flutter 的高性能，也能在性能不太好的手机上稳定运行~
时间：（占坑）
下载：（测试/调整中，上架后会第一时间更新）
技术参考：（占坑）

![FotoJet1.jpg](https://img.hacpai.com/file/2019/12/FotoJet1-a9dc41ef.jpg)


