title: 正式发布武汉肺炎可视化APP - 全民战疫 最新版本v1.1.0
date: '2020-01-30 22:02:29'
updated: '2020-01-30 22:02:29'
tags: [Android]
permalink: /articles/2020/01/30/1580392949324.html
---
![](https://img.hacpai.com/bing/20180410.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# 序言
最近武汉肺炎 2019-nCoV来势汹汹，全城戒备。虽然是一个普通市民，但也是想在这次天灾中做点什么。于是，利用春节时间完成了这么一个APP。


# Question
#### Q 网上已经有很多的实时疫情网页，能很方便的查看疫情，为什么还需要一个APP？

#### A 这个APP最大的特点就是能查看历史数据，有更直观的可视化图表。通过拖动时间轴能看到疫情随着时间的扩散情况，这是疫情网页所不提供的。另外，对于中老年人来说，获取信息的途径没有年轻人那么丰富。他们不玩微博不刷抖音。这个APP除了疫情信息外，还有实时新闻，各种资讯链接，能更方便的了解最新信息。

#### Q 数据来源可靠真实吗？

#### A 1月24前的数据来自腾讯新闻，1月24后的数据来自GIthub项目https://github.com/BlankerL/DXY-2019-nCoV-Crawler ，已获取作者同意，其实也就是爬自丁香园的实时数据。

# 截图
<img src="https://img.hacpai.com/file/2020/01/image-478e2aee.png" width="40%">
<img src="https://img.hacpai.com/file/2020/01/image-e4110836.png" width="40%">
<img src="https://img.hacpai.com/file/2020/01/image-b649fcb5.png" width="40%">
<img src="https://img.hacpai.com/file/2020/01/image-a6721046.png" width="40%">
<img src="https://img.hacpai.com/file/2020/01/image-55a6caa5.png" width="40%">
<img src="https://img.hacpai.com/file/2020/01/image-4dbabdea.png" width="40%">
<img src="https://img.hacpai.com/file/2020/01/image-62cf7505.png" width="40%">
<img src="https://img.hacpai.com/file/2020/01/image-f75b1146.png" width="40%">
<img src="https://img.hacpai.com/file/2020/01/image-b60f4bf4.png" width="40%">



# 更新公告
最新版本 1.1.0
下载地址：http://file.moyck.com/ncov_1.1.0.apk

~