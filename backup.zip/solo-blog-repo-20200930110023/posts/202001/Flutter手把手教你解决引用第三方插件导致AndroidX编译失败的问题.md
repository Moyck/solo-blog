title: Flutter 手把手教你解决引用第三方插件导致 AndroidX 编译失败的问题
date: '2020-01-07 17:50:21'
updated: '2020-01-07 17:50:21'
tags: [Flutter]
permalink: /articles/2020/01/07/1578390621389.html
---
![](https://img.hacpai.com/bing/20181206.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# 序言
最近学习了Flutter一段时间，确实感觉到Flutter是一个未来的大趋势，更新到1.12后一套代码能在全平台运行。（Andorid,IOS,Linux,Windows,Web,Mac）并且相对来说学习难度不大，语法，工具都比较现代与先进。实在建议各位APP开发或者前端开发好好学一学。好了说重点，今天我的同事运行Flutter项目时就出现了一个AndroidX的兼容问题，虽然对我来说不是什么大问题，但是对于没有Android开发经验的前端来说可能这个问题会卡一天。因此还是留下这个解决方案，~~好好做人，贡献社会~~

# 问题标识
引入第三方插件后，重新在Android上编译出现错误提示
~~~
java.lang.RuntimeException: Duplicate class android.support.v4.app.INotificationSideChannel found in modules classes.jar (androidx.core:core:1.0.2) and classes.jar (com.android.support:support-compat:28.0.0)
~~~

同时出现androidx  com.android.support字样的一般都是androidx  的兼容问题了

![image.png](https://img.hacpai.com/file/2020/01/image-d6f27d6c.png)

# 错误分析
android.support 是早前的Android 开发工具包，大部分的控件都是依赖这个。但是由于历史原因已经出现了android.support.v4  v7  v13等各个版本，每次更新版本，相关控件的包名都要替换。为了解决这个麻烦的版本更新问题，现在统一江湖改为 androidx ，因此出现这个support与androidx的冲突问题。

# 解决步骤
既然知道了问题所在，那修复起来也就不难了。

基于你有没有Android Studio 这里有两种方式，推荐先下载 Android Studio
### 方式1 不使用Android Studio
[网上教程很多，这里贴一个，但是估计没有Android开发经验也很难改好](https://www.jianshu.com/p/029c1f527135)

### 方式2 使用Android Studio （推荐）
下载Android Studio最新版

使用Android Studio打开你的Flutter项目下的Android目录
![image.png](https://img.hacpai.com/file/2020/01/image-21e825e7.png)

等待编译完成，时间可能需要几分钟不等

![image.png](https://img.hacpai.com/file/2020/01/image-116426c5.png)

编译完后可以看到运行的图标绿了 绿了绿了 它绿了

![image.png](https://img.hacpai.com/file/2020/01/image-f51234c4.png)

然后点击Refactor 的 Migrate to AndoridX

![image.png](https://img.hacpai.com/file/2020/01/image-19490d8d.png)

可以把备份关掉

![image.png](https://img.hacpai.com/file/2020/01/image-7c9a6bac.png)

然后点击下面的Do Refactor

![image.png](https://img.hacpai.com/file/2020/01/image-584f5e09.png)

之后稍等片刻就可以正常运行了

# 后续问题
博主你骗人呀，我弄完了上一步还是出现别的错误了，还我血汗钱！

同学别着急，一般来说弄完上面一步就可以解决问题了。但是也有不一般的情况，就是androidX的版本不一致导致的问题 大概报错提示可以看到 
 
`androidx.core:core:1.1.0  ... androidx.core:core:1.0.0 ` 之类的，就说明是版本不一致了 

解决方法也好办 

打开 build.gradle  module:app这个文件

![image.png](https://img.hacpai.com/file/2020/01/image-7fec7d44.png)

详细地址是 android/app/build.gradle

![image.png](https://img.hacpai.com/file/2020/01/image-eba0cdc2.png)


在android{} 里面复制如下代码

```
configurations.all {
        resolutionStrategy {
            resolutionStrategy.eachDependency { details ->
                if (details.requested.group == 'androidx.core') {
                    details.useVersion "1.0.1"
                }
                if (details.requested.group == 'androidx.lifecycle') {
                    details.useVersion "2.0.0"
                }
                if (details.requested.group == 'androidx.versionedparcelable') {
                    details.useVersion "1.0.0"
                }
                if (details.requested.group == 'androidx.fragment') {
                    details.useVersion "1.0.0"
                }
                if (details.requested.group == 'androidx.appcompat') {
                    details.useVersion "1.0.1"
                }
            }
        }
    }
```

![image.png](https://img.hacpai.com/file/2020/01/image-e0f6f6ba.png)

这段代码的作用就是固定androidx.core的版本，让插件的版本也保持一致，接着点击上方的Sync Now 等待下载完成就可以了。

# 尾语
这次的解决步骤已经截图很明确了，如果真的有帮到你的话，帮我点下 (我的Solo博客)[http://www.moyck.com/]广告就好了~嘿