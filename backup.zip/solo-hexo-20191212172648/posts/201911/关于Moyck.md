title: 关于Moyck
date: '2019-11-29 15:46:36'
updated: '2019-12-11 17:27:03'
tags: [Android, Coder, 杂谈]
permalink: /articles/2019/11/29/1575013596580.html
---

![](https://img.hacpai.com/bing/20190311.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# 关于
我是Moyck，一位个人开发者
### 感谢每个能看到这里的人
我是个沉没寡言的人，从小就喜欢玩各种电子设备
可能就是因为对电子设备这份喜欢，让我走上了编程的路并乐此不疲
在现实生活中，我是一间外包公司里唯一的Android开发工程师
常常同时要进行多个项目，每天都很忙碌但感觉日子并不充实

想了想，身不由己的工作似乎有点辜负了当年满怀梦想的自己

于是，我决心要做一位独立开发者，做自己所喜欢的事情

#### 从今起，我会不定时在 Blog/知乎/CSDN 里面发布我开发的 IOS / Android App 或 游戏 或 小说

#### 计划发布99个APP为止

#### 另外因为上架应用商店都需要软件著作权，因此选择蒲公英分发，密码默认 0000

一般，我会将我工作中学到的一个知识点作为一个App，并会附带该App的相关知识点，以供要实现该功能的开发者参考。

另外，我的APP尽量没有广告（除非成本过高），如果你喜欢我的创作，可以请我喝杯奶茶～

### 已实现的APP

#### 条码大师 
平台：Android 
简介：识别或生成二维码，条形码
时间：2019/12/2
相关： [Android 二维码/条形码的识别或生成](http://www.moyck.com:8080/articles/2019/11/29/1575025314278.html)
下载：https://www.pgyer.com/NcP1 密码 0000
![NcP1.png](https://img.hacpai.com/file/2019/12/NcP1-652f0049.png)



![FotoJet.jpg](https://img.hacpai.com/file/2019/11/FotoJet-f56ffcea.jpg)

<br/>
<br/>

#### 简创 （暂定）
平台：Android / IOS（待发布）
简介：既然开始决心做APP开发，自然需要UI设计了。总不能边写界面边调整吧。鉴于本人PS,XD都是半桶水水平，那干脆自己撸一个可以设计UI的APP吧！ 该APP是用Flutter写的，因此兼容Android IOS，并且得益于Flutter 的高性能，也能在性能不太好的手机上稳定运行~
时间：（占坑）
相关：（占坑）
下载：（测试/调整中）
技术参考：（占坑）

![FotoJet1.jpg](https://img.hacpai.com/file/2019/12/FotoJet1-a9dc41ef.jpg)

<br/>
<br/>

#### Recorder 251
平台：Android
简介：不是所有人都会随时携带录音笔的，李洪元事件如果发生在我们身上，可能就不只是251了。华为鸿蒙发布会的时候我正非常骄傲的坐在最前排，但是看到李洪元事件发生到知乎删帖，热度减退时心里不由有点芥蒂。好的时候成为民族英雄，不好的事情也请客观公正。这个APP就是在这个背景下产生的，与其说它是一个应用，倒不如说它是我对这件事的态度吧。这个APP看上去是个浏览器，其实当点击菜单栏的星星后就会开始录音，点击下载按钮进入到录音记录界面。
时间：2019/12/11
相关：
下载：https://www.pgyer.com/Bd5b 密码： 0000
![Bd5b.png](https://img.hacpai.com/file/2019/12/Bd5b-2173b1ed.png)

![FotoJet1.png](https://img.hacpai.com/file/2019/12/FotoJet1-5bdfe5b0.png)


