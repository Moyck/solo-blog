title: 分享一下用procreate画的图 新手勿喷 hhhhh
date: '2020-02-13 12:34:52'
updated: '2020-02-13 12:34:52'
tags: [画画]
permalink: /articles/2020/02/13/1581568492214.html
---
在家闲的无事，买了iPad + pencil 学一下画画，下面就是花了半天时间画出来的成果了，问题很多但是自己挺满意的 hhhh

![31581568110.pichd.jpg](https://img.hacpai.com/file/2020/02/31581568110.pichd-9a448986.jpg)