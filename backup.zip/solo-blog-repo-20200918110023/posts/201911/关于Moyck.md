title: 关于Moyck
date: '2019-11-29 15:46:36'
updated: '2019-11-29 15:46:36'
tags: [Android, Coder, 杂谈]
permalink: /articles/2019/11/29/1575013596580.html
---
![](https://img.hacpai.com/bing/20190311.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# 关于
我是Moyck，一位普通的开发者
### 感谢每个能看到这里的人
我是个沉默寡言的人，从小就喜欢玩各种电子设备
可能就是因为对电子设备这份喜欢，让我走上了编程的路并乐此不疲
在现实生活中，我是一间外包公司里唯一的Android开发工程师
常常同时要进行多个项目，每天都很忙碌但感觉日子并不充实

于是，决定在业余时间，做自己所喜欢的事情

我会将我所做的成果分享到这里，大部分是但不一定只有APP，可能还有小说，游戏等（看心情啦）


#### 另外因为上架应用商店都需要软件著作权，也没有好的地方给我扔安装包，因此选择蒲公英分发，密码默认 0000

一般，我会将我工作中学到的一个知识点作为一个App，并会附带该App的相关知识点，以供要实现该功能的开发者参考。

如果你喜欢我的创作，可以帮我点下广告～

### 已实现的APP

#### 条码大师 
平台：Android 
简介：识别或生成二维码，条形码
时间：2019/12/2
相关： [Android 二维码/条形码的识别或生成](http://www.moyck.com:8080/articles/2019/11/29/1575025314278.html)
下载：https://www.pgyer.com/NcP1 密码 0000
[Google Play下载](https://play.google.com/store/apps/details?id=com.moyck.barcodemaster)

![NcP1.png](https://img.hacpai.com/file/2019/12/NcP1-652f0049.png)




![FotoJet.jpg](https://img.hacpai.com/file/2019/11/FotoJet-f56ffcea.jpg)

<br/>
<br/>

#### 简创 （暂定）
平台：Android / IOS（待发布）
简介：既然开始决心做APP开发，自然需要UI设计了。总不能边写界面边调整吧。鉴于本人PS,XD都是半桶水水平，那干脆自己撸一个可以设计UI的APP吧！ 该APP是用Flutter写的，因此兼容Android IOS，并且得益于Flutter 的高性能，也能在性能不太好的手机上稳定运行~
时间：（占坑）
相关：（占坑）
下载：（测试/调整中）
技术参考：（占坑）

![FotoJet1.jpg](https://img.hacpai.com/file/2019/12/FotoJet1-a9dc41ef.jpg)

<br/>
<br/>

#### Recorder 251
平台：Android
简介：不是所有人都会随时携带录音笔的，李洪元事件如果发生在我们身上，可能就不只是251了。华为鸿蒙发布会的时候我正非常骄傲的坐在最前排，但是看到李洪元事件发生到知乎删帖，热度减退时心里不由有点芥蒂。好的时候成为民族英雄，不好的事情也请客观公正。这个APP就是在这个背景下产生的，与其说它是一个应用，倒不如说它是我对这件事的态度吧。这个APP看上去是个浏览器，其实当点击菜单栏的星星后就会开始录音，点击下载按钮进入到录音记录界面。
时间：2019/12/11
相关：
下载：https://www.pgyer.com/Bd5b 密码： 0000
[Google Play下载](https://play.google.com/store/apps/details?id=com.moyck.recoder251)

![Bd5b.png](https://img.hacpai.com/file/2019/12/Bd5b-2173b1ed.png)

![FotoJet1.png](https://img.hacpai.com/file/2019/12/FotoJet1-5bdfe5b0.png)

#### 全民站疫 - 武汉肺炎实时数据可视化
平台：Android
简介：最近武汉肺炎 2019-nCoV来势汹汹，全城戒备。虽然是一个普通市民，但也是想在这次天灾中做点什么。于是，利用春节时间完成了这么一个APP，实际用时大概是三天。由于时间仓促，这个APP可能会有界面兼容，卡顿，崩溃等BUG，如果发现了，请私信告知。
这个APP最大的特点就是能查看历史数据，有更直观的可视化图表。通过拖动时间轴能看到疫情随着时间的扩散情况，这是疫情网页所不提供的。另外，对于中老年人来说，获取信息的途径没有年轻人那么丰富。他们不玩微博不刷抖音。这个APP除了疫情信息外，还有实时新闻，各种资讯链接，能更方便的了解最新信息。 1月24前的数据来自腾讯新闻，1月24后的数据来自GIthub项目[https://github.com/BlankerL/DXY-2019-nCoV-Crawler](https://link.zhihu.com/?target=https%3A//github.com/BlankerL/DXY-2019-nCoV-Crawler) ，已获取作者同意，其实也就是爬自丁香园的实时数据。
相关：[正式发布武汉肺炎可视化APP - 全民战疫 最新版本v1.1.0](http://www.moyck.com/articles/2020/01/30/1580392949324.html)
下载：http://file.moyck.com/ncov_1.1.0.apk

<img src="https://img.hacpai.com/file/2020/01/image-478e2aee.png" width="40%">
<img src="https://img.hacpai.com/file/2020/01/image-e4110836.png" width="40%">